# Little Bird

A no-subscription, single-file starter prototype for a personal digital bird.

## Open it
Open `index.html` in a browser. On iPhone, the easiest route is to publish the folder with GitHub Pages, then open the published URL in Safari and use Share -> Add to Home Screen.

## What this prototype does
- Customisable bird name
- Animated CSS bird and small neon-city scene
- Offline, rule-based chat personality
- Explore / wonder / rest activities
- Journal, curiosity score and visit count saved in browser local storage
- When reopened after a long gap, it creates a clearly-labelled imagined adventure

## Important limitations
This is a prototype, not a conscious creature or a continuously running AI. The bird does not actually run while Safari is closed; on return it can create a simulated catch-up entry. The chat is rule-based and offline, not a large language model. Browser storage is local to that browser/device and may be cleared by the user or iOS.

GitHub Pages can host the static files for free in a public repository. Static hosting does not provide a 24/7 background worker or private server-side AI.
