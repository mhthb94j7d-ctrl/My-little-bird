# Rook's World — Version 2

Upload `index.html` to the root of your existing GitHub repository, replacing the previous file, then commit the change. GitHub Pages will publish the update.

This version gives the crow a mixed character (curious, playful, thoughtful, independent and sociable on his terms), weighted self-selected activities, interests that grow when he repeats topics, recent-activity avoidance, a journal and a chat personality.

It preserves the browser storage key `littleBird.v1`, so the existing saved name and journal should carry over in the same browser on the same device.

Important: this is an offline rule-based prototype, not a cloud language model, conscious being, or 24/7 background process. It makes activity choices only while the page is open; when reopened after a long gap it records a clearly labelled imagined catch-up, not real activity performed while closed. Data stays in that browser's local storage and may be lost if browser data is cleared or the device/browser changes.
