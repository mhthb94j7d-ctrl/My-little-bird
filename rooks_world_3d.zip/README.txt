ROOK'S WORLD — 3D OPEN-WORLD PROTOTYPE

Files:
- index.html: the complete browser experience.

HOW TO RUN
1. Upload index.html to the ROOT of the same GitHub repository used for the earlier Rook project, replacing the old root index.html if one exists.
2. Commit the change.
3. Open the repository's GitHub Pages website. The first load needs an internet connection because Three.js is loaded from jsDelivr.
4. On iPhone, open the Pages URL in Safari. If you see an old version, refresh the page.

CONTROLS
- Drag: orbit the camera.
- Pinch / scroll: zoom.
- WASD / arrow keys: move the camera target.
- Follow Rook: camera follows the crow.
- Free camera: stop following.
- Call Rook: invite him to come closer.

WHAT'S INCLUDED
- Procedural 3D woodland, rolling meadow, stream, trees, rocks, logs and small shiny objects.
- A procedurally modelled black carrion crow named Rook, with walking and flapping flight animation.
- Autonomous rule-based behaviours: explore, investigate, perch, rest, forage and drink.
- Curiosity, hunger, thirst and energy needs.
- Mixed personality and curious temperament reflected in his activity selection.

LIMITATIONS
This is an early playable prototype, not a finished high-fidelity animal simulator. Rook's autonomy is rule-based, not consciousness or a language-model brain. The simulation runs while the page is open; it does not continue running after the browser is closed. It currently uses a procedural crow model rather than a scanned/rigged photorealistic bird asset.
